import {
  Article,Attachment,Product,ProductCategory,ProductAttachment,Category,
  ProductSpec,Author,User,Affiliate,Purshase,Supplier,Owner,Orgz,
  Branch,Subscriber,PurshaseItem,Payment,supTicket,Verification,
  OrgzAttachment, Subscription,AffiliateProduct,VerifyCode,Password,
  
} from "./";

export const entities:any=[
  
  Article,Attachment,Product,ProductAttachment,ProductCategory,
  ProductSpec, Author,User,Purshase,PurshaseItem,
  Payment,supTicket,Verification,Affiliate,Supplier,
  Owner,Orgz,Branch,OrgzAttachment, Subscriber,
  Password ,Subscription,AffiliateProduct,VerifyCode, Category
]
