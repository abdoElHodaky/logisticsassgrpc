export abstract class Dto {}
