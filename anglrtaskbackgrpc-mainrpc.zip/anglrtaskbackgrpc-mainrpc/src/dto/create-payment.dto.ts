export class CreatePaymentDto {
   readonly userId:number
   readonly purshaseId:number
}
