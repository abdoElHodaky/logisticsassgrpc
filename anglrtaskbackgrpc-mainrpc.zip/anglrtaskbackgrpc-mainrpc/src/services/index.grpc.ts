
export {ArticleGrpcService} from "./articles.grpc";
export {TicketGrpcService} from "./tickets.grpc";
export {AuthGrpcService} from "./auth.grpc";
export {AuthorGrpcService} from "./authors.grpc";
export {UserGrpcService} from "./users.grpc";
export {supTicketGrpcService} from "./suptickets.grpc";
export {orgzGrpcService} from "./orgzs.grpc";
export { ProductGrpcService} from "./products.grpc";
export { PurshaseGrpcService} from "./purchases.grpc";
