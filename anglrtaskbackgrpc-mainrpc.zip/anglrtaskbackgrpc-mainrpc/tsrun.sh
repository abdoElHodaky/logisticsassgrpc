#!/user/bin/bash

npm-run-all build swaggen start

#node ./dist/grpc-reflect.js
#npm-run-all --parallel start
